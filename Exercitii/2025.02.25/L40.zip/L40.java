interface Validation {
    boolean validate(); 
    String outputAsLabel();
}

class Person {
    public String name; 
    public String phoneNumber; 
    public String email; 
    public Address address;

    public void purchaseParkingPass() {
        System.out.println("Do you have a parking pass?");
    }

}

class Student extends Person {
    public int studentNumber; 
    public double averageMark;

    public boolean isEligibaleToEnroll() { 
        if (averageMark > 5)
            return true;
        else
            return false;
    }

    public int[] getSeminarsTaken() {
        return new int[]{ 234,12,54,765,215};
    };

}

class Address implements Validation {
    public String street;
    public String city; 
    public String state; 
    public String postalCode; 
    public String country;

    public boolean validate() { 
        if (street == null)
            return false;
        if (city == null)
            return false;
        if (state== null) 
            return false;
        if (postalCode == null) 
            return false;
        if (country == null) 
            return false;

        return true;
    }

    public String outputAsLabel() {
    return "Street:" + street + "\n" + "\t City:" + city + "\n" + "\t State:" + state + "\n" +
    "\t Postal code:" + postalCode + "\n" + "\t Country:" + country + "\n";
    }

}

class Profesor extends Person{
    private int salary;
}

public class L40 {

    public static void main(String[] args) { 

        Student student = new Student(); 
        student.studentNumber = 23; 
        student.name = "George";
        student.averageMark = 5.5;
        
        Address addressStudent = new Address();
        addressStudent.street = "Splaiul Independentei, nr 34"; 
        addressStudent.city = "Bucuresti";
        addressStudent.country = "Romania";
        addressStudent.postalCode = "130-776"; 
        addressStudent.state = "Ilfov"; 
        student.address = addressStudent;

        // test student's info
        System.out.println( 
        "Student: " + student.name + "\n" + 
        "Register number: " + student.studentNumber + "\n" + 
        "Average mark: " + student.averageMark + " is valid to enroll:" + student.isEligibaleToEnroll() + "\n"+ 
        "Courses ids: " + student.getSeminarsTaken().toString() + "\n" +
        "Address:" + (student.address.validate() ? student.address. outputAsLabel() : "is not completed.") );
    }
}
